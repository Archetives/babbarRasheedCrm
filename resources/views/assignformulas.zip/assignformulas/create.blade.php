{{ Form::model( array('route' => ['imgformulas.store'])) }}
<div class="modal-body">
    <div class="row">
        <div class="col-6 form-group">
        <label class="">Name</label>
                        <input class="form-control" type="hidden" name="id" id="imageid">
                        <input class="form-control" valus="{{$image->id}}" type="text" name="name" id="name">
        </div>
 
     
    </div>
</div>

<div class="modal-footer">
    <input type="button" value="{{__('Cancel')}}" class="btn  btn-light" data-bs-dismiss="modal">
    <input type="submit" value="{{__('Update')}}" class="btn  btn-primary">
</div>

{{Form::close()}}


